package com.example.calculateur;

public enum Monnaie {
    EURO,
    DOLLAR,
    LIVRE_STERLING
}
